1.How to play your game

	Mouse: Turning; aiming; camera movement.
	Mouse Wheel: Scrolls through the quick-bar and the chat when opened.
	ESC: Opens up the menu and gives back cursor control. Pauses Singleplayer games. Closes any open GUI. Exits the chat/command window.
	Left shift: Start sprinting.
	Space: Jump.
	WASD: Move the character.
	F5: Change the perspective of the camera.
T: Open the command input field.

2.Environment
	By generating a random hight map by some algorithm, we created the map totally randomized but also will not be too bumpy.
	The Ground Surface are all Grass block, which have different textures on 6 sides, and under that will be dirt and various stone blocks.
	Then there will be two kind of trees, with transparent leaves.Also the Log blocks has also different textures on each side.

3.Your game
	The Day and Night cycle exists,  and the monster(slimes, it means to be) appear after dawn, disappears in early morning.
	The hotbar has 9 slot, each can store 64 of 1 kind of block.
	Also the Inventory auto sorts when there is any empty slots.
	

4.Game design (how to design your character, monster, etc.)
	We divide character into several parts, like moving, jumping, head rotating...etc.
	In terms of the jumping feature, we use a trigger under the character to detect whether the player is on the ground or not. Player can��t move in the air, but if the player tries to jump without the initial speed(like jumping upstairs), he can get an extra chance to move.


5.Bonus
	We made a command input field, which can let us enter some command codes.
	The player can change the looking direction by moving the mouse.
	The player can jump vertically onto a block.
	The capability to sprint.
	A crosshair at the middle of the screen. 
	Unity Chan in cute! lovely! adorable!
6.Feedback
	Time isn't enough!


